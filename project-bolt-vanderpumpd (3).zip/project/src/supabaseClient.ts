// src/supabaseClient.ts
import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Read from localStorage safely (works with Step 4A)
function readLS(key: string): string {
  try { return localStorage.getItem(key) || ''; } catch { return ''; }
}

// Optional env bridges (some hosts inject __ENV)
const env = (typeof window !== 'undefined' ? (window as any).__ENV : undefined) || (import.meta as any)?.env || {};

const lsUrl = readLS('vp_supabase_url');
const lsKey = readLS('vp_supabase_key');
const envUrl = String(env.VITE_SUPABASE_URL || '');
const envKey = String(env.VITE_SUPABASE_ANON_KEY || '');

const SUPABASE_URL = lsUrl || envUrl;
const SUPABASE_KEY = lsKey || envKey;

export const hasSupabaseConfig =
  !!(import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY);

// If configured, make a real client
let client: SupabaseClient | any;
if (hasSupabaseConfig) {
  client = createClient(SUPABASE_URL, SUPABASE_KEY);
} else {
  // Safe no-op stub so the app doesn't crash when not configured
  const noCfg = async () => ({ data: null, error: new Error('Supabase not configured') });
  client = {
    auth: {
      getSession: async () => ({ data: { session: null }, error: null }),
      getUser:    async () => ({ data: { user: null }, error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe() {} } } }),
      signInWithPassword: noCfg,
      signUp:             noCfg,
      resetPasswordForEmail: noCfg,
      updateUser:         noCfg,
      signOut:            async () => ({ error: null })
    },
    from() {
      const chain = {
        select: noCfg, insert: noCfg, upsert: noCfg, update: noCfg, delete: noCfg,
        eq() { return chain; }, in() { return chain; }, order() { return chain; },
        maybeSingle: async () => ({ data: null, error: null }),
single:      async () => ({ data: null, error: null })
      };
      return chain;
    }
  };
}

export const supabase = client;