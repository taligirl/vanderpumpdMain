import React, { useEffect, useMemo, useRef, useState } from 'react';
import { supabase, hasSupabaseConfig } from './supabaseClient';
import { NotificationsTab } from './components/NotificationsTab';
import { VirtualEpisodeList } from './components/VirtualEpisodeList';
import { FriendsTab } from './components/FriendsTab';
import { DiaryTab } from './components/DiaryTab';
import { BrowseTab } from './components/BrowseTab';
import { SettingsTab } from './components/SettingsTab';
import { useSupabaseAuth, getCurrentUser, requireAuth, detectRecoveryFromUrl } from './lib/auth';
import ErrorBoundary from './components/ErrorBoundary';
import { HeartButton, RatingInput } from './components/UiAtoms';
import { EpisodeReviews } from './components/EpisodeReviews';
import { CollectionsTab } from './components/CollectionsTab';
import { CollectionPicker } from './components/CollectionPicker';
import { PublicProfileView } from './components/PublicProfileView';
import { ResetPasswordModal } from './components/ResetPasswordModal';
import { AvatarCropModal } from './components/AvatarCropModal';
import { CoverCropModal } from './components/CoverCropModal';
import AppShell from './layout/AppShell';
import { AppCtx } from './ctx/AppCtx';
import { REVIEW_HEART, type ReviewHeart, reactionValue } from './lib/constants';
import { toggleReviewReaction } from './lib/commentsApi';
import {
  ACTIVE_UID,
  EPISODES_KEY, RATINGS_KEY, FAVS_KEY, REVIEWS_KEY, PROFILE_KEY,
  COLLECTIONS_KEY, ACTIVITY_KEY, WATCHED_KEY, PUBLIC_REPLIES_KEY
} from './lib/storage';
import { ProfileTab } from './pages/ProfileTab';
import { GlobalStyles } from './components/GlobalStyles';
import { TopAuthBar } from './components/TopAuthBar';
import { formatStars } from './lib/stars';
import { ToastHost, pushToast } from './components/Toast';
import {
  readImageFileToDataURL, resizeImageToDataURL, cropToAspectDataURL, cropToAspectDataURLAt,
} from './lib/image';
import { safeGetJSON, openReportMail } from './lib/utils';
import type { Episode, Comment, ActivityItem, ReviewItem, PublicReply } from './types';

/* [COMMENTS4-CONST+TYPES] */
const COMMENTS_PAGE = 20; // per parent branch page size

const PKEY = (pid: string | null) => (pid ?? 'root');

/* [COMMENT-REACTIONS-CONST] replies use 👍 / 👎 */
type ReplyEmoji = '👍' | '👎';
const replyValue = (e: ReplyEmoji) => (e === '👎' ? -1 : 1);

/* --Types-- */
function todayISO() { return new Date().toISOString().slice(0,10); }

type CustomCollection = { id: string; name: string; keywords: string[]; episodeIds: string[]; description?: string };

/* --Helpers-- */

// Copy helper used in multiple places
async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    // Fallback
    const ok = await (await import('./utils/clipboard')).copyText(text);
    return ok;
  } catch {
    return false;
  }
}

// Toggle block/unblock a user for the current account
async function toggleBlock(targetUserId: string): Promise<'blocked'|'unblocked'|null> {
  const u = await requireAuth(); if (!u) return null;
  try {
    // Is there an existing block?
    const { data: existing } = await supabase
      .from('blocks')
      .select('blocked_user_id')
      .eq('user_id', u.id)
      .eq('blocked_user_id', targetUserId)
      .maybeSingle();

    if (existing) {
      const { error } = await supabase
        .from('blocks')
        .delete()
        .eq('user_id', u.id)
        .eq('blocked_user_id', targetUserId);
      if (error) throw error;
      pushToast('Unblocked.');
      return 'unblocked';
    } else {
      const { error } = await supabase
        .from('blocks')
        .insert({ user_id: u.id, blocked_user_id: targetUserId, created_at: new Date().toISOString() });
      if (error) throw error;
      pushToast('Blocked.');
      return 'blocked';
    }
  } catch (e:any) {
    // If table missing, Supabase returns an error; we just surface it.
    pushToast(e?.message || 'Failed to update block.');
    return null;
  }
}

/* --App-- */

export default function App() {
  const isMountedRef = useRef(true);
useEffect(() => { return () => { isMountedRef.current = false; }; }, []);
  const { user, recovery } = useSupabaseAuth();
  const isAdmin = !!(user?.email && user.email.toLowerCase() === 'tjbenlev@gmail.com');
// Track user-id for storage namespace and reload per-account bundles
const lastUidRef = React.useRef<string>('init');

React.useEffect(() => {
  const uid = user?.id || 'anon';
  try { localStorage.setItem('vp_uid', uid); } catch {}
  if (lastUidRef.current !== uid) {
    lastUidRef.current = uid;
    setRatings(safeGetJSON(RATINGS_KEY(), {}));
    setFavs(safeGetJSON(FAVS_KEY(), {}));
    setReviews(safeGetJSON(REVIEWS_KEY(), {}));
    setCollections(safeGetJSON(COLLECTIONS_KEY(), []));
    setActivity(safeGetJSON(ACTIVITY_KEY(), []));
    setWatchedAt(safeGetJSON(WATCHED_KEY(), {}));
    setProfile(safeGetJSON(PROFILE_KEY(), {
      name:"You", avatar:"", bio:"", handle:"", isPublic:false, cover_url:"", featuredCollectionIds:[]
    }));
    if (user) { loadOwnProfileFromDB(); }
  }
}, [user?.id, hasSupabaseConfig]);

  // image crop modals
  const [avatarCropSrc, setAvatarCropSrc] = useState<string | null>(null);
  const [coverCropSrc, setCoverCropSrc] = useState<string | null>(null);
  const [showReset, setShowReset] = useState(false);

  React.useEffect(() => {
    if (recovery) {
      setTab('settings');       // jump user to Settings tab
      setShowReset(true);       // open ResetPasswordModal
    }
  }, [recovery]);

  // Handle Supabase magic-link return (e.g. ?code=...)
  const [followersCount, setFollowersCount] = useState(0);
const [followingCount, setFollowingCount] = useState(0);

/* --- avatar & cover uploads --- */
const avatarFileRef = useRef(null);
const coverFileRef  = useRef(null);

async function handleAvatarFileChange(e: React.ChangeEvent<HTMLInputElement>) {
  const input = e.currentTarget;                  // snapshot before await
  const file = input.files?.[0];
  if (!file) return;
  try {
    const raw = await readImageFileToDataURL(file);
if (!isMountedRef.current) return;
setAvatarCropSrc(raw);
  } catch (err) {
    console.error(err);
    pushToast('Sorry—could not read that image.');
  } finally {
    input.value = '';                             // safe: we kept a reference
  }
}

async function handleCoverFileChange(e: React.ChangeEvent<HTMLInputElement>) {
  const input = e.currentTarget;                  // snapshot before await
  const file = input.files?.[0];
  if (!file) return;
  try {
    const raw = await readImageFileToDataURL(file);
if (!isMountedRef.current) return;
setCoverCropSrc(raw);
  } catch (err) {
    console.error(err);
    pushToast('Sorry—could not read that image.');
  } finally {
    input.value = '';                             // safe clear
  }
}

  // Tabs
  const [tab, setTab] = useState('browse');
  
// [PH-OPEN-HANDLE-PROFILE] shim for "@handle" clicks used in comments/activity/etc.
const openHandleProfile = React.useCallback((input: any) => {
  try {
    // Accept either a string like "@tali" or an object with handle-ish fields
    const raw =
      typeof input === 'string'
        ? input
        : (input?.handle ?? input?.authorHandle ?? input?.userHandle ?? '');
    const handle = String(raw || '').replace(/^@/, '');

    // Navigate to Profile tab
    setTab('profile');

    // Default the profile subtabs to 'reviews' if the helper exists
    try { (window as any).__vpSetProfileTab?.('reviews'); } catch {}

    // If you later add a real loader-by-handle, this will call it automatically
    const loadByHandle =
      (window as any).__vpLoadProfileByHandle ||
      (window as any).__vpOpenProfileByHandle ||
      null;
    if (typeof loadByHandle === 'function') {
      loadByHandle(handle);
    } else {
      // breadcrumb others can read if needed
      (window as any).__vpLastHandle = handle;
      try { history.pushState({}, '', `#@${handle}`); } catch {}
    }
  } catch (e) {
    console.warn('[openHandleProfile] fallback', e);
    setTab('profile');
  }
}, [setTab]);

// Optional: expose globally for any legacy inline handlers
;(window as any).openHandleProfile = openHandleProfile;

 function goTab(next: string) {
  if (unsaved && !confirm('You have unsaved changes. Leave without saving?')) return;
  if (unsaved) setUnsaved(false); // clear the dirty flag once user agrees to leave
  setTab(next);
}
 
  React.useEffect(() => {
  if (!user) setTab('browse');
}, [!!user]);

const [notifCount, setNotifCount] = useState(0);
 // [PH-NOTIF-COUNT-REALTIME]
React.useEffect(() => {
  if (!hasSupabaseConfig || !user?.id) { setNotifCount(0); return; }

  const LS_KEY = `vp_last_notif_seen_${user.id}`;

  async function refreshCount() {
    const { data } = await supabase
      .from('notifications')
      .select('id,created_at')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50);
        let last = 0;
    try { last = Number(localStorage.getItem(LS_KEY) || 0); } catch { last = 0; }
    const c = (data || []).filter(n => {
  const t = n.created_at ? new Date(n.created_at).getTime() : 0;
  return t > last;
}).length;
if (!isMountedRef.current) return;
setNotifCount(c);
  }

  // initial + realtime
  refreshCount();
  const ch = supabase
    .channel(`notifs-count:${user.id}`)
    .on('postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` },
      () => refreshCount()
    )
    .subscribe();

  return () => { try { supabase.removeChannel(ch); } catch {} };
}, [hasSupabaseConfig, user?.id]);

// [PH-REALTIME-REVIEW-LIKES-GLOBAL] keep any visible rr-count-* badges fresh
// [PH-REALTIME-REVIEW-HEART:GLOBAL] keep any rr-heart-count-* fresh
React.useEffect(() => {
  if (!hasSupabaseConfig) return;

  async function refreshVisible() {
    const nodes = Array.from(document.querySelectorAll('span[id^="rr-heart-count-"]')) as HTMLSpanElement[];
    const ids = [...new Set(nodes.map(n => n.id.replace('rr-heart-count-', '')).filter(Boolean))];
        for (const id of ids) {
      try {
        const { count } = await supabase
          .from('review_reactions')
          .select('id', { count:'exact' })
          .eq('review_id', id)
          .eq('emoji', REVIEW_HEART)
          .limit(1);
        const el = document.getElementById(`rr-heart-count-${id}`);
        if (el) {
          el.textContent = String(count ?? 0);
        }
      } catch {}
    }
  }

  refreshVisible();
  const ch = supabase
    .channel('rr:all')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'review_reactions' }, refreshVisible)
    .subscribe();
  const int = setInterval(refreshVisible, 10000);

  return () => { try { supabase.removeChannel(ch); } catch {} clearInterval(int); };
}, [hasSupabaseConfig]);
 
  const [reviewView, setReviewView] = useState('all');

  // Profile subtab state (followers/following switch)
const [profileTab, setProfileTab] = React.useState<'reviews'|'activity'|'followers'|'following'>('reviews');

// Expose a safe global setter for the header buttons
React.useEffect(() => {
  (window as any).__vpSetProfileTab = setProfileTab;
  return () => { try { delete (window as any).__vpSetProfileTab; } catch {} };
}, []);

  // Import (Merge/Replace)
  const [importMode, setImportMode] = useState('replace');

  React.useEffect(() => {
  (async () => {
    if (!hasSupabaseConfig) { setFollowersCount(0); setFollowingCount(0); return; }
    const user = await getCurrentUser();
    if (!user) { setFollowersCount(0); setFollowingCount(0); return; }

    const { count: folCount } = await supabase
      .from('follows')
      .select('*', { count:'exact', head:true })
      .eq('following_id', user.id); // people who follow me
    const { count: ingCount } = await supabase
      .from('follows')
      .select('*', { count:'exact', head:true })
      .eq('follower_id', user.id); // people I follow

    setFollowersCount(folCount || 0);
    setFollowingCount(ingCount || 0);
  })();
}, []);

// Episodes
const [catalog, setCatalog] = useState<Episode[]>([]);
const episodes = catalog;

// Load shared catalog from Supabase (episodes table) — with local fallback
useEffect(() => {
  let alive = true;

  (async () => {
    // 1) Try Supabase first (if configured)
    try {
      if (hasSupabaseConfig) {
        const { data, error } = await supabase
          .from('episodes')
          .select('*')
          .order('season', { ascending: true })
          .order('number', { ascending: true });

        if (!error && data && alive) {
          setCatalog(data as Episode[]);
          return; // success; stop here
        }
      }
    } catch (e) {
      // ignore and fall back
    }

    // 2) Fallback: try local /catalog.json in public/
    try {
      const res = await fetch('/catalog.json', { cache: 'no-store' });
      if (res.ok) {
        const j = await res.json();
        if (alive && Array.isArray(j)) setCatalog(j as Episode[]);
      }
    } catch (e) {
      // still nothing; leave catalog as-is
    }
  })();

  return () => { alive = false; };
}, [hasSupabaseConfig]);

useEffect(() => {
  (async () => {
    if (!hasSupabaseConfig) return;
    const u = await getCurrentUser();
    if (!u) return;

    const [r1, r2, r3, r4] = await Promise.all([
      supabase.from('ratings').select('ep_id, stars'),
      supabase.from('favorites').select('ep_id'),
      supabase.from('collections').select('id, name, keywords, description').order('created_at', { ascending: false }),
    supabase
  .from('watch_events')
  .select('ep_id, watched_on')
  .eq('event', 'watch')
  .order('watched_on', { ascending: false }),
    ]);

    const rmap: Record<string, number> = {};
    (r1.data || []).forEach((row:any) => { rmap[row.ep_id] = row.stars; });
    setRatings(rmap);

    const fmap: Record<string, boolean> = {};
    (r2.data || []).forEach((row:any) => { fmap[row.ep_id] = true; });
    setFavs(fmap);

    // Build: counts per ep, list of dates (newest-first), and a fallback last-watched timestamp map
const counts: Record<string, number> = {};
const dates: Record<string, string[]> = {};
const wmap: Record<string, number> = {};
(r4.data || []).forEach((row:any) => {
  const ep = row.ep_id;
  const d = String(row.watched_on || '').slice(0,10);
  if (!ep || !d) return;
  counts[ep] = (counts[ep] || 0) + 1;
  (dates[ep] ||= []).push(d);
});
// sort newest-first; set watchedAt fallback to latest date’s timestamp
Object.keys(dates).forEach(ep => {
  dates[ep].sort((a,b)=> (a < b ? 1 : a > b ? -1 : 0));
  wmap[ep] = new Date(dates[ep][0]).getTime();
});
setWatchCounts(counts);
setWatchDates(dates);
setWatchedAt(wmap);

    const base = (r3.data || []).map((c:any) => ({
      id: c.id, name: c.name, keywords: c.keywords || [], description: c.description || '', episodeIds: [] as string[]
    }));
    if (base.length) {
      const ids = base.map(c => c.id);
      const { data: items } = await supabase
        .from('collection_items')
        .select('collection_id, ep_id')
        .in('collection_id', ids);
      const byId = new Map(base.map(c => [c.id, c]));
      (items || []).forEach((it:any) => {
        const col = byId.get(it.collection_id);
        if (col && !col.episodeIds.includes(it.ep_id)) col.episodeIds.push(it.ep_id);
      });
      setCollections(Array.from(byId.values()));
    } else {
      setCollections([]);
    }
  })();
}, [hasSupabaseConfig]);
  

  // State bundles
  const [ratings, setRatings] = useState<Record<string, number>>(() => safeGetJSON(RATINGS_KEY(), {}));
  const [favs, setFavs] = useState<Record<string, boolean>>(() => safeGetJSON(FAVS_KEY(), {}));
  const [reviews, setReviews] = useState<Record<string, ReviewItem[]>>(() => safeGetJSON(REVIEWS_KEY(), {}));
  const [collections, setCollections] = useState<CustomCollection[]>(() => safeGetJSON(COLLECTIONS_KEY(), []));
  const [activity, setActivity] = useState<ActivityItem[]>(() => safeGetJSON(ACTIVITY_KEY(), []));
  const [watchedAt, setWatchedAt] = useState<Record<string, number>>(() => safeGetJSON(WATCHED_KEY(), {}));
  // public replies (local)

const [publicReplies, setPublicReplies] = useState<Record<string, PublicReply[]>>(
  () => safeGetJSON(PUBLIC_REPLIES_KEY(), {})
);
useEffect(() => {
  try { localStorage.setItem(PUBLIC_REPLIES_KEY(), JSON.stringify(publicReplies)); } catch {}
}, [publicReplies]);

function addPublicReply(parentId: string, text: string) {
  const t = (text || '').trim();
  if (!t) return;
  const me = (window as any).__vprProfile || {};
  setPublicReplies(map => {
    const list = map[parentId] ? [...map[parentId]] : [];
    list.push({
      id: `${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
      parentId,
      text: t,
      ts: Date.now(),
      authorName: me.name || 'You',
      authorHandle: me.handle ? `@${String(me.handle).replace(/^@/,'')}` : '',
      authorAvatar: me.avatar || ''
    });
    return { ...map, [parentId]: list };
  });
}

  // [PH-COMMENTS-API]
// Load all comments (root + replies) for one review
// [KEEP-LOADCOMMENTS-CANON]
async function loadComments(reviewId: string) {
  const { data, error } = await supabase
    .from('comments')
    .select(`
      id,
      review_id,
      parent_id,
      text,
      created_at,
      author_id,
      profiles:author_id (
        id,
        display_name,
        handle,
        avatar_url
      )
    `)
    .eq('review_id', reviewId)
    .order('created_at', { ascending: true });

  if (error) {
    console.error('comments select error', error);
    return;
  }
  // --- Reaction counts per comment (👍/👎) ---
  const ids = (data ?? []).map((r: any) => r.id);
  const reactionCounts: Record<string, Record<string, number>> = {};

  if (ids.length) {
    const { data: rx, error: rxErr } = await supabase
      .from('comment_reactions')
      .select('comment_id, emoji')
      .in('comment_id', ids);

    if (rxErr) {
      console.error('reaction counts error', rxErr);
    } else {
      for (const r of rx ?? []) {
        const cid = String((r as any).comment_id);
        const e = String((r as any).emoji ?? '');
        if (!reactionCounts[cid]) reactionCounts[cid] = {};
        reactionCounts[cid][e] = (reactionCounts[cid][e] || 0) + 1;
      }
    }
  }

const rows = (data ?? []).map((row: any) => {
  const createdTs = row.created_at ? Date.parse(row.created_at) : Date.now();
  const display = row.profiles?.display_name ?? null;
  const handle = row.profiles?.handle ? `@${row.profiles.handle}` : '';
  const avatar = row.profiles?.avatar_url ?? '';

  return {
    id: row.id,
    review_id: row.review_id,
    parent_id: row.parent_id,
    text: row.text,
    created_at: row.created_at,
    ts: createdTs,
    author_id: row.author_id,
    authorName: display || 'User',
    authorHandle: handle,
    authorAvatar: avatar,
    reactions: reactionCounts[row.id] || undefined
  };
});

if (!isMountedRef.current) return;
setCommentsByReview(prev => ({
  ...prev,
  [reviewId]: rows
}));
}

// Add a comment to a review (optionally a reply to another comment)
async function addComment(reviewId: string, parentId: string | null, text: string) {
  if (!hasSupabaseConfig) { pushToast('Connect Supabase to comment.'); return; }
  const u = await requireAuth(); if (!u) return;

  const t = (text || '').trim();
  if (!t) return;

  // DB insert — NOTE: column names must match your table!
  const { data, error } = await supabase
    .from('comments')
    .insert({
      review_id: reviewId,
      parent_id: parentId,
      text: t,
      author_id: u.id,
      user_id: u.id,
    })
    .select('id, created_at')
    .single();

  if (error) {
    console.error('comments insert error', error);
    pushToast('Could not post comment. Please try again.');
    return;
  }
  
// Refresh from server so the thread shows the new comment
await loadComments(reviewId);
// [PH-NOTIF-ON-REPLY] notify review owner or parent comment author
try {
  const me = await requireAuth(); if (!me) throw new Error('no user');

  let targetUserId: string | null = null;
  let reviewForNotif: string | null = reviewId;
  let commentForNotif: string | null = (data as any)?.id ?? null;

  if (parentId) {
    const { data: parent } = await supabase
      .from('comments')
      .select('author_id, review_id')
      .eq('id', parentId)
      .maybeSingle();
    targetUserId = parent?.author_id ?? null;
    reviewForNotif = parent?.review_id ?? reviewId;
  } else {
    const { data: rev } = await supabase
      .from('reviews')
      .select('user_id')
      .eq('id', reviewId)
      .maybeSingle();
    targetUserId = rev?.user_id ?? null;
  }

  if (targetUserId && targetUserId !== me.id) {
    await supabase.from('notifications').insert({
      user_id: targetUserId,
      actor_id: me.id,
      type: 'reply',
      review_id: reviewForNotif,
      comment_id: commentForNotif
    });
  }
} catch (e) {
  console.warn('[notif:reply] skipped', e);
}

// Optional: optimistic local append if you keep comments in state
try {
  if (!isMountedRef.current) return;
  setCommentsByReview(prev => {
    const list = prev[reviewId] ? [...prev[reviewId]] : [];
    list.push({
      id: data?.id || `${Date.now()}`,
      review_id: reviewId,
      parent_id: parentId ?? null,
      text: t,
      ts: Date.now(),
      authorName: profile?.name || 'You',
      authorHandle: profile?.handle ? `@${profile.handle}` : '',
      authorAvatar: profile?.avatar || '',
    });
    return { ...prev, [reviewId]: list };
  });
} catch {}

// Toggle 👍 / 👎 per user per comment (DB unique on (comment_id, user_id))
// Behavior:
//  - No existing row -> INSERT {emoji, value}
//  - Existing row with same emoji -> DELETE (toggle off)
//  - Existing row with different emoji -> UPDATE to new {emoji, value}
async function toggleCommentReaction(commentId: string, emoji: string) {
  console.warn('[CLICK] toggleCommentReaction', { commentId, emoji });
  pushToast('Old comment reactions are disabled in this build.');
return;

    if (!hasSupabaseConfig) { pushToast('Connect Supabase to react.'); return; }
    const u = await requireAuth(); if (!u) return;
    const v = (emoji === '👍' ? 1 : -1);

    // Look up ANY existing reaction by this user for this comment
    const { data: existing, error: selErr } = await supabase
      .from('comment_reactions')
      .select('id, emoji, value')
      .eq('comment_id', commentId)
      .eq('user_id', u.id)
      .maybeSingle();

    if (selErr && selErr.code !== 'PGRST116') { // ignore "no rows" style
      console.error('reaction select error', selErr);
      pushToast('Could not read reactions');
      return;
    }

    if (existing?.id) {
      if (existing.emoji === emoji) {
        // Same emoji -> toggle off
        const { error: delErr } = await supabase
          .from('comment_reactions')
          .delete()
          .eq('id', existing.id);
        if (delErr) {
          console.error('reaction delete error', delErr);
          pushToast('Could not remove reaction');
        }
      } else {
        // Different emoji -> update existing row (no duplicate insert)
        const { error: updErr } = await supabase
          .from('comment_reactions')
          .update({ emoji, value: v })
          .eq('id', existing.id);
        if (updErr) {
          console.error('reaction update error', updErr);
          pushToast('Could not change reaction');
        }
        // [PH-NOTIF-ON-THUMB-UP:UPDATE]
if (!updErr && emoji === '👍') {
  try {
    const { data: c } = await supabase
      .from('comments')
      .select('author_id, review_id')
      .eq('id', commentId)
      .maybeSingle();

    const target = c?.author_id ?? null;
    if (target && target !== u.id) {
      await supabase.from('notifications').insert({
        user_id: target,
        actor_id: u.id,
        type: 'thumb_up',
        review_id: c?.review_id ?? null,
        comment_id: commentId
      });
    }
  } catch (e) {
    console.warn('[notif:thumb_up:update] skipped', e);
  }
}
      }
      return;
    }

  // Preflight: make sure the comment actually exists in public.comments
const { data: exists } = await supabase
  .from('comments')
  .select('id')
  .eq('id', commentId)
  .maybeSingle();
if (!exists?.id) {
  pushToast('Save this comment first (needs a real ID).');
  return;
}

    // No existing -> insert fresh
    const { error: insErr } = await supabase
      .from('comment_reactions')
      .insert({
        comment_id: commentId,
        user_id: u.id,
        emoji,
        value: v
      });

    if (insErr) {
      console.error('reaction insert error', insErr);
const code = (insErr as any).code;
pushToast(code ? `Could not add reaction (${code})` : 'Could not add reaction');
return;
      // [PH-NOTIF-ON-THUMB-UP:INSERT]
if (!insErr && emoji === '👍') {
  try {
    const { data: c } = await supabase
      .from('comments')
      .select('author_id, review_id')
      .eq('id', commentId)
      .maybeSingle();

    const target = c?.author_id ?? null;
    if (target && target !== u.id) {
      await supabase.from('notifications').insert({
        user_id: target,
        actor_id: u.id,
        type: 'thumb_up',
        review_id: c?.review_id ?? null,
        comment_id: commentId
      });
    }
  } catch (e) {
    console.warn('[notif:thumb_up:insert] skipped', e);
  }
}
    }
}

  // Real comments (by reviewId)
const [commentsByReview, setCommentsByReview] = useState<Record<string, Comment[]>>({});

// Profile state (lazy init from localStorage) + a save-in-progress flag
const [profile, setProfile] = useState<{
  name: string;
  avatar: string;
  bio?: string;
  handle?: string;
  isPublic?: boolean;
  cover_url?: string;
  featuredCollectionIds?: string[];
}>(() => safeGetJSON(PROFILE_KEY(), {
  name: "You",
  avatar: "",
  bio: "",
  handle: "",
  isPublic: false,
  cover_url: "",
  featuredCollectionIds: []
}));

const [savingProfile, setSavingProfile] = useState(false);
const [unsaved, setUnsaved] = useState(false);
const [saveToast, setSaveToast] = useState<string>('');

useEffect(() => {
  if (typeof window === 'undefined') return;

  const onBeforeUnload = (e: BeforeUnloadEvent) => {
    if (!unsaved) return;
    e.preventDefault();
    e.returnValue = ''; // required for Chrome
  };
  window.addEventListener('beforeunload', onBeforeUnload);
  return () => window.removeEventListener('beforeunload', onBeforeUnload);
}, [unsaved]);

// let the share-image helper read my current name/handle/avatar
  useEffect(() => {
  if (typeof window === 'undefined') return;
  (window as any).__vprProfile = profile;
}, [profile]);
  useEffect(() => { try { localStorage.setItem(RATINGS_KEY(), JSON.stringify(ratings)); } catch {} }, [ratings]);
  useEffect(() => { try { localStorage.setItem(FAVS_KEY(), JSON.stringify(favs)); } catch {} }, [favs]);
  useEffect(() => { try { localStorage.setItem(REVIEWS_KEY(), JSON.stringify(reviews)); } catch {} }, [reviews]);
  useEffect(() => {try { localStorage.setItem(COLLECTIONS_KEY(), JSON.stringify(collections)); } catch {}}, [collections]);
  useEffect(() => { try { localStorage.setItem(ACTIVITY_KEY(), JSON.stringify(activity)); } catch {} }, [activity]);
  useEffect(() => { try { localStorage.setItem(PROFILE_KEY(), JSON.stringify(profile)); } catch {} }, [profile]);
  useEffect(() => { try { localStorage.setItem(WATCHED_KEY(), JSON.stringify(watchedAt)); } catch {} }, [watchedAt]);

  function addActivity(item: Omit<ActivityItem, 'id' | 'ts'> & Partial<Pick<ActivityItem, 'ts'>>) {
    setActivity(prev => {
      const now = Date.now();
      const ts = item.ts ?? now;
      const keyType = item.type;
      const keyEp   = item.epId ?? '';
      const keyDet  = item.detail ?? '';
            // Phase 4: coalesce rating events per episode within 10 minutes
      if (keyType === 'rating' && keyEp) {
        const tenMin = 10 * 60 * 1000;
        // Find the most recent 'rating' event for this episode within the last 10 minutes
        const idx = prev.findIndex(a =>
          a.type === 'rating' &&
          (a.epId ?? '') === keyEp &&
          (now - (a.ts ?? 0)) <= tenMin
        );
        if (idx !== -1) {
          // Replace the last rating event (update ts + detail)
          const updated = { ...prev[idx], ts, detail: keyDet };
          const copy = [...prev];
          copy[idx] = updated;
          return copy;
        }
      }

      const dup = prev.find(a =>
        Math.abs((a.ts ?? 0) - ts) < 1000 &&
        a.type === keyType &&
        (a.epId ?? '') === keyEp &&
        (a.detail ?? '') === keyDet
      );
      if (dup) return prev;
      const next: ActivityItem = {
        id: `${ts}-${Math.random().toString(36).slice(2,8)}`,
        ts,
        type: keyType,
        epId: item.epId,
        detail: item.detail
      };
      return [next, ...prev].slice(0, 500);
    });
  }

  // Ratings & Favorites (with specific activity message)
  function setRating(epId: string, v: number) {
  (async () => {
    if (!hasSupabaseConfig) { pushToast('Connect Supabase to rate.'); return; }
    const u = await requireAuth(); if (!u) return;

    const stars = Math.max(0, Math.min(5, v));
  
    // [PH-A1] only log activity if > 0 stars
setRatings(r => {
  const before = r[epId] || 0;
  const next = { ...r, [epId]: stars };
  if (stars > 0 && before !== stars) {
    addActivity({ type: 'rating', epId, detail: String(stars) });
  }
  return next;
});

    const { error } = await supabase
      .from('ratings')
      .upsert({ user_id: u.id, ep_id: epId, stars, updated_at: new Date().toISOString() });

    if (error) {
      console.error(error);
      pushToast('Could not save rating online.');
    }
  })();
}


  function toggleFav(epId: string) {
  (async () => {
    if (!hasSupabaseConfig) { pushToast('Connect Supabase to favorite.'); return; }
    const u = await requireAuth(); if (!u) return;

    const wasFav = !!favs[epId];
    setFavs(f => {
      const nowFav = !wasFav;
      const next = { ...f, [epId]: nowFav };
      if (nowFav) addActivity({ type: 'favorited', epId, detail: 'Favorited' });
      return next;
    });

    if (wasFav) {
      const { error } = await supabase.from('favorites').delete().eq('user_id', u.id).eq('ep_id', epId);
      if (error) console.error(error);
    } else {
      const { error } = await supabase.from('favorites').upsert({
        user_id: u.id, ep_id: epId, created_at: new Date().toISOString()
      });
      if (error) console.error(error);
    }
  })();
}

// Log a watch on a chosen date (YYYY-MM-DD)
async function logWatch(epId: string, dateISO: string) {
  if (!hasSupabaseConfig) { pushToast('Connect Supabase to log watches.'); return; }
  const u = await requireAuth(); if (!u) return;
  const d = (dateISO || '').slice(0,10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) { pushToast('Pick a date'); return; }

  const { error } = await supabase
  .from('watch_events')
  .insert({ ep_id: epId, watched_on: d, user_id: u.id, event: 'watch' });
if (error) { console.error('watch insert error', error); pushToast(error.message || 'Could not log watch'); return; }

if (!isMountedRef.current) return;
// optimistic local update
setWatchCounts(m => ({ ...m, [epId]: (m[epId] || 0) + 1 }));
  setWatchDates(m => {
    const cur = m[epId] || [];
    const next = [d, ...cur.filter(x => x !== d)]; // keep newest-first, no dup
    return { ...m, [epId]: next };
  });
  setWatchedAt(m => ({ ...m, [epId]: new Date(d).getTime() }));
  setWatchDateInputs(m => { const copy = { ...m }; delete copy[epId]; return copy; });
  // [PH-WATCH-AS-REVIEW] also create a blank review entry for this watch
try {
  const starsSnap = ratings[epId] || 0;
  // Use the picked date as the review's created_at (no time chosen -> noon UTC)
  const createdAt = new Date(`${d}T12:00:00.000Z`).toISOString();

  const { data: ins, error: revErr } = await supabase
    .from('reviews')
    .insert({
      user_id: u.id,
      ep_id: epId,
      text: '', // blank text is fine; user can add/edit later
      stars_at_post: starsSnap,
      created_at: createdAt
    })
    .select('id, stars_at_post, created_at')
    .single();

  // Optimistic local add
  const newItem: ReviewItem = {
    id: ins?.id || `${Date.now()}`,
    text: '',
    starsAtPost: ins?.stars_at_post ?? starsSnap,
    ts: ins?.created_at ? new Date(ins.created_at).getTime() : Date.now(),
    authorName: profile?.name || 'You',
    authorHandle: profile?.handle ? `@${String(profile.handle).replace(/^@/,'')}` : '',
    authorAvatar: profile?.avatar || ''
  };
  setReviews(m => {
    const list = m[epId] ? [newItem, ...m[epId]] : [newItem];
    return { ...m, [epId]: list };
  });
  addActivity({ type: 'review_add', epId, detail: '', ts: newItem.ts });

  if (revErr) console.warn('[watch->review] insert failed (kept local):', revErr);
} catch (e) {
  console.warn('[watch->review] fallback:', e);
}
}

  // Demo public reviews — memoized
  const demoPublicReviews = useMemo(() => ({
    S1E1: [
      { id: "pub1", author: "Taylor", handle: "@tay", text: "Iconic pilot, the SUR drama starts strong.", ts: Date.now() - 86400000 },
      { id: "pub2", author: "Chris", handle: "@chr1s", text: "Funny moments and so much foreshadowing.", ts: Date.now() - 5400000 },
    ],
    S1E2: [
      { id: "pub3", author: "Mia", handle: "@miami", text: "The breakup chaos… Wow.", ts: Date.now() - 7200000 },
    ],
  }), []);
  function getDemoPublicReviews(epId: string) { return (demoPublicReviews as any)[epId] || []; }

  // Episode modal
  const [openEpisodeId, setOpenEpisodeId] = useState(null);
  const openEpisode = (id: string) => {
    setOpenEpisodeId(id);
    // keep deep link in URL while open
    try { history.replaceState(null, '', `${location.pathname}#${id}`); } catch {}
  };
  const closeEpisode = () => {
    setOpenEpisodeId(null);
    // clear deep link
    try { history.replaceState(null, '', location.pathname + (publicRoute ? '#u' : '')); } catch {}
  };

  // Filters + sorting + funny tags
  type SearchIn = "all" | "title" | "description" | "reviews";
  const [query, setQuery] = useState("");
  const [searchIn, setSearchIn] = useState<SearchIn>("all");
  const [seasonFilter, setSeasonFilter] = useState<number | "all">("all");
  const seasonOptions = React.useMemo(
    () => Array.from(new Set((episodes || catalog || []).map(e => e.season))).sort((a, b) => a - b),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [episodes, catalog]
  );
  const [minStars, setMinStars] = useState<number>(0);
  const [onlyFavs, setOnlyFavs] = useState(false);
  const [onlyWatched, setOnlyWatched] = useState(false);
const [onlyUnwatched, setOnlyUnwatched] = useState(false);
  const [onlyRated, setOnlyRated] = useState(false);
  const [hideWatched, setHideWatched] = useState(false);
  const [watchCounts, setWatchCounts] = useState<Record<string, number>>({});
const [watchDates, setWatchDates] = useState<Record<string, string[]>>({});
const [watchDateInputs, setWatchDateInputs] = useState<Record<string, string>>({});
const [watchDateFilter, setWatchDateFilter] = useState<string>('');
  type SortKey = "season-asc" | "season-desc" | "my-stars-desc" | "my-stars-asc";
  const [sortBy, setSortBy] = useState<SortKey>("season-asc");
  const [collectionFilterId, setCollectionFilterId] = useState<string>("all");
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  type Tags = { costumes: boolean; jaxShirtOff: boolean; tequilaKatie: boolean; vegas: boolean; reunion: boolean };
  const episodeTags = (ep: Episode): Tags => {
  const explicit = new Set((ep.tags || []).map(s => s.toLowerCase()));
  const t = `${ep.title} ${ep.description}`.toLowerCase();
  const guess: Tags = {
    costumes: /costume|halloween|surlesque|burlesque|dress|wig/.test(t),
    jaxShirtOff: /jax[^a-z]*shirt|shirtless|abs/.test(t),
    tequilaKatie: /tequila|katie rant|rage[- ]text|rage text/.test(t),
    vegas: /vegas|sin city|bachelor|bachelorette/.test(t),
    reunion: /reunion/.test(t),
  };
  return {
    costumes: explicit.has('costumes') || guess.costumes,
    jaxShirtOff: explicit.has('jaxshirtoff') || explicit.has('jax_shirt_off') || explicit.has('jax-shirt-off') || guess.jaxShirtOff,
    tequilaKatie: explicit.has('tequilakatie') || explicit.has('tequila_katie') || explicit.has('tequila-katie') || guess.tequilaKatie,
    vegas: explicit.has('vegas') || guess.vegas,
    reunion: explicit.has('reunion') || guess.reunion,
  };
};

  const [funny, setFunny] = useState<Tags>({ costumes:false, jaxShirtOff:false, tequilaKatie:false, vegas:false, reunion:false });

  const applyFilters = (list: Episode[]) => {
  const q = (query || '').toLowerCase();
  return list.filter((ep) => {
    if (seasonFilter !== "all" && ep.season !== seasonFilter) return false;
    if (onlyFavs && !favs[ep.id]) return false;
    if (onlyRated && !(ratings[ep.id] > 0)) return false;
if (minStars > 0 && (ratings[ep.id] || 0) < minStars) return false;

    // watched logic
    const isWatched = !!watchedAt[ep.id];
    if (onlyWatched && !isWatched) return false;
    if (onlyUnwatched && isWatched) return false;
    
    // filter by a specific watch date (YYYY-MM-DD) if set
if (watchDateFilter) {
  const dates = watchDates[ep.id] || [];
  if (!dates.includes(watchDateFilter)) return false;
}

    // search logic
    if (q) {
      const inTitle = ep.title.toLowerCase().includes(q);
      const inDesc = ep.description.toLowerCase().includes(q);
      const inReviews = (reviews[ep.id] || []).some((r) => (r.text || '').toLowerCase().includes(q));
      if (searchIn === "title" && !inTitle) return false;
      if (searchIn === "description" && !inDesc) return false;
      if (searchIn === "reviews" && !inReviews) return false;
      if (searchIn === "all" && !(inTitle || inDesc || inReviews)) return false;
    }

    // funny tags
    const tags = episodeTags(ep);
    if (funny.costumes && !tags.costumes) return false;
    if (funny.jaxShirtOff && !tags.jaxShirtOff) return false;
    if (funny.tequilaKatie && !tags.tequilaKatie) return false;
    if (funny.vegas && !tags.vegas) return false;
    if (funny.reunion && !tags.reunion) return false;
    return true;
  });
};


  // Collections helpers (duplicate-name guard)
  const createCollection = (name: string, keywords: string[] = []) => {
  (async () => {
    if (!hasSupabaseConfig) { pushToast('Connect Supabase to save collections.'); return; }
    const u = await requireAuth(); if (!u) return;

    const clean = name.trim();
    if (!clean) return;

    const { data, error } = await supabase
      .from('collections')
      .insert({ user_id: u.id, name: clean, keywords, description: '' })
      .select('id, name, keywords, description')
      .single();

    if (error) { console.error(error); pushToast('Could not create collection'); return; }

    setCollections(arr => [{ id: data.id, name: data.name, keywords: data.keywords || [], description: data.description || '', episodeIds: [] }, ...arr]);
    addActivity({ type: 'collection_add', detail: clean });
  })();
};
  
  const updateCollection = (collectionId: string, patch: Partial<CustomCollection>) => {
  (async () => {
    if (!hasSupabaseConfig) return pushToast('Connect Supabase to edit collections.');
    const u = await requireAuth(); if (!u) return;

    const toSend: any = {};
    if (patch.name != null) toSend.name = patch.name;
    if (patch.keywords != null) toSend.keywords = patch.keywords;
    if (patch.description != null) toSend.description = patch.description;
    toSend.updated_at = new Date().toISOString();

    const { error } = await supabase.from('collections').update(toSend).eq('id', collectionId);
    if (error) { console.error(error); pushToast('Could not update collection'); return; }

    setCollections(arr => arr.map(c => c.id === collectionId ? ({ ...c, ...patch }) : c));

    
  })();
};
  
  // ✅ single source of truth: add/remove episode in a collection (also persist to Supabase)
const addEpisodeToCollection = (collectionId: string, epId: string) => {
  (async () => {
    // update local state immediately
    setCollections(arr =>
      arr.map(c =>
        c.id === collectionId
          ? (c.episodeIds.includes(epId) ? c : { ...c, episodeIds: [...c.episodeIds, epId] })
          : c
      )
    );

    // persist online (if configured)
    if (!hasSupabaseConfig) return;
    const u = await requireAuth(); if (!u) return;

    const { error } = await supabase
      .from('collection_items')
      .upsert({ collection_id: collectionId, ep_id: epId });
    if (error) console.error('collection_items upsert error', error);
  })();
};

const removeEpisodeFromCollection = (collectionId: string, epId: string) => {
  (async () => {
    // update local state immediately
    setCollections(arr =>
      arr.map(c =>
        c.id === collectionId
          ? { ...c, episodeIds: c.episodeIds.filter(id => id !== epId) }
          : c
      )
    );

    // persist online (if configured)
    if (!hasSupabaseConfig) return;
    const u = await requireAuth(); if (!u) return;

    const { error } = await supabase
      .from('collection_items')
      .delete()
      .eq('collection_id', collectionId)
      .eq('ep_id', epId);
    if (error) console.error('collection_items delete error', error);
  })();
};

  // Review helpers (+ activity)
const addReview = (epId: string, text: string) => {
  (async () => {
    const t = (text || '').trim();
    if (!t) return;

    if (!hasSupabaseConfig) { pushToast('Connect Supabase to post reviews.'); return; }
    const u = await requireAuth(); if (!u) return;

const starsSnap = ratings[epId] || 0;

const { data: ins, error } = await supabase
  .from('reviews')
  .insert({
    user_id: u.id,
    ep_id: epId,
    text: t,
    stars_at_post: starsSnap,
    created_at: new Date().toISOString()
  })
  .select('id, stars_at_post')
  .single();

    const newItem: ReviewItem = {
      id: ins?.id || `${Date.now()}`,
      text: t,
      starsAtPost: ins?.stars_at_post ?? starsSnap,
      ts: Date.now(),
      authorName: profile?.name || 'You',
      authorHandle: profile?.handle ? `@${profile.handle}` : '',
      authorAvatar: profile?.avatar || ''
    };
    setReviews(m => {
      const list = m[epId] ? [...m[epId]] : [];
      list.unshift(newItem);
      return { ...m, [epId]: list };
    });
    addActivity({ type: 'review_add', epId, detail: t });

    if (error) {
      console.error('Supabase insert reviews error:', error);
      pushToast('Could not save review online. It’s saved locally.');
    }
  })();
};


  const editReview = (epId: string, reviewId: string, newText: string) => {
    setReviews(m => {
      const list = (m[epId] || []).map(r => r.id === reviewId ? { ...r, text: newText } : r);
      return { ...m, [epId]: list };
    });
    addActivity({ type: 'review_edit', epId, detail: 'Edited review' });
  };

  const deleteReview = (epId: string, reviewId: string) => {
  (async () => {
    // Optimistic local removal
    setReviews(m => {
      const list = (m[epId] || []).filter(r => r.id !== reviewId);
      return { ...m, [epId]: list };
    });

    // Persist online if possible
    if (!hasSupabaseConfig) return;
    const u = await requireAuth(); if (!u) return;

    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', reviewId)
      .eq('user_id', u.id);

    if (error) console.error('[deleteReview] supabase delete error:', error);
  })();
};
  
const deleteLatestReview = (epId: string) => {
  const list = (reviews[epId] || []).slice().sort((a,b)=> (b.ts||0) - (a.ts||0));
  const latest = list[0];
  if (!latest?.id) { pushToast('No review to delete'); return; }
  if (confirm('Delete the latest review?')) deleteReview(epId, latest.id);
};

  // final list (memo)
  const finalList = useMemo(() => {
    let base = episodes;
    if (collectionFilterId !== "all") {
      const selected = collections.find(c => c.id === collectionFilterId);
      if (selected) {
        const manualIds = new Set(selected.episodeIds || []);
        const kws = (selected.keywords || []).map(s => s.toLowerCase());
        base = base.filter(ep => {
          const text = `${ep.title} ${ep.description}`.toLowerCase();
          const byKeywords = kws.length > 0 && kws.some(kw => text.includes(kw));
          return manualIds.has(ep.id) || byKeywords;
        });
      }
    }
  const filtered = applyFilters(base).filter(ep => !(hideWatched && watchedAt[ep.id]));
    const out = [...filtered];
    const myStars = (id: string) => (ratings[id] || 0);
    switch (sortBy) {
  case "season-asc":
    out.sort((a,b) => (a.season - b.season) || (a.episode - b.episode));
    break;
  case "season-desc":
    out.sort((a,b) => (b.season - a.season) || (b.episode - a.episode));
    break;
  case "my-stars-desc":
    out.sort((a,b) => myStars(b.id) - myStars(a.id) || a.title.localeCompare(b.title));
    break;
  case "my-stars-asc":
    out.sort((a,b) => myStars(a.id) - myStars(b.id) || a.title.localeCompare(b.title));
    break;
}

    return out;
  }, [
  episodes,
  ratings,
  favs,
  reviews,
  collections,
  watchedAt,
  watchDates,
  watchDateFilter,
  query,
  searchIn,
  seasonFilter,
  minStars,
  onlyFavs,
  onlyRated,
  onlyWatched,
  onlyUnwatched,
  hideWatched,
  sortBy,
  collectionFilterId,
  funny.costumes,
  funny.jaxShirtOff,
  funny.tequilaKatie,
  funny.vegas,
  funny.reunion
]);

  function getFavorites(): Episode[] { return episodes.filter(ep => !!favs[ep.id]); }

  function resetFilters() {
    setQuery('');
    setSearchIn('all');
    setSeasonFilter('all');
    setMinStars(0);
    setOnlyFavs(false);
    setOnlyRated(false);
    setOnlyWatched(false);
    setOnlyUnwatched(false);
    setHideWatched(false);
    setSortBy('season-asc');
    setCollectionFilterId('all');
    setFunny({ costumes:false, jaxShirtOff:false, tequilaKatie:false, vegas:false, reunion:false });
  }

  // Activity row (now shows episode info)
  function buildShareText(ep: Episode, review?: ReviewItem) {
    return [
      `Vanderpumpd Review`,
      `Episode: S${ep.season}E${ep.episode}: ${ep.title}`,
      review?.ts ? `When: ${new Date(review.ts).toLocaleString()}` : '',
      review?.text ? `\n${review.text}` : ''
    ].filter(Boolean).join('\n');
  }

  // UI tags dropdown state
  const [showTags, setShowTags] = useState(false);

  // Simple routing via hash: #S2E4, #u, #u/@handle
  const [publicRoute, setPublicRoute] = useState<string | null>(null);
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const applyHash = () => {
      const raw = window.location.hash || '';
      const hash = raw.startsWith('#') ? raw.slice(1) : raw; // strip leading "#"

      // Episode deep link: "S1E1", "S2E4", etc.
      if (/^S\d+E\d+$/i.test(hash)) {
        setOpenEpisodeId(hash.toUpperCase());
        setPublicRoute(null);
        setTab('browse');
        return;
      }

      // Local "#u" profile route (overlay handles "#u/..." separately)
      if (hash.toLowerCase() === 'u') {
        setPublicRoute('u');
        setOpenEpisodeId(null);
        return;
      }

      // Anything else: clear local route
      setPublicRoute(null);
      setOpenEpisodeId(null);
    };

    applyHash();
    const onHash = () => applyHash();
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

/* Ensure a profile row exists, and save edits to the cloud */
async function saveProfileNow() {
  if (!hasSupabaseConfig || !user) return;

  const handleRaw = (profile.handle || '').replace(/^@/, '').trim().toLowerCase();
  const cleanHandle = handleRaw || null;

  if (cleanHandle && !/^[a-z0-9_]{3,20}$/.test(cleanHandle)) {
    pushToast('Handle must be 3–20 chars, lowercase letters/numbers/underscores.');
    return;
  }

  const payload = {
    id: user.id,
    handle: cleanHandle,
    display_name: profile.name || null,
    avatar_url: profile.avatar || null,
    cover_url: profile.cover_url || null,
    bio: profile.bio || null,
    is_public: !!profile.isPublic,
    updated_at: new Date().toISOString()
  };

  const { data: row, error } = await supabase
    .from('profiles')
    .upsert(payload)
    .select('id, handle, display_name, avatar_url, bio, is_public, cover_url')
    .single();

  if (error) {
   if ((error as any).code === '23505' || /duplicate|unique/i.test(error.message || '')) {
  pushToast('That handle is already taken. Pick another one.');
} else {
  pushToast('Could not save profile. Please try again.');
}
    return;
  }

  // Mirror DB row to React state + localStorage (so refresh sticks)
  const next = {
    name: row.display_name || 'You',
    avatar: row.avatar_url || '',
    bio: row.bio || '',
    handle: row.handle || '',
    isPublic: !!row.is_public,
    cover_url: row.cover_url || '',
    featuredCollectionIds: Array.isArray((profile as any)?.featuredCollectionIds)
      ? (profile as any).featuredCollectionIds
      : []
  };

  if (!isMountedRef.current) return;
setProfile(prev => ({ ...prev, ...next }));
try { localStorage.setItem(PROFILE_KEY(), JSON.stringify({ ...(profile as any), ...next })); } catch {}
}
  // Load my profile row from Supabase and mirror it into local state + localStorage
async function loadOwnProfileFromDB() {
  if (!hasSupabaseConfig) return;
  const u = await getCurrentUser();
  if (!u) return;

  const { data, error } = await supabase
    .from('profiles')
    .select('handle, display_name, avatar_url, cover_url, bio, is_public')
    .eq('id', u.id)
    .maybeSingle();

  if (error) {
    console.warn('profile fetch error', error);
    return;
  }
  if (!data) return;

  const next = {
    name: data.display_name || 'You',
    avatar: data.avatar_url || '',
    bio: data.bio || '',
    handle: data.handle || '',
    isPublic: !!data.is_public,
    cover_url: data.cover_url || '',
    featuredCollectionIds: Array.isArray((profile as any)?.featuredCollectionIds)
      ? (profile as any).featuredCollectionIds
      : []
  };

  if (!isMountedRef.current) return;
setProfile(prev => ({ ...prev, ...next }));
try {
  localStorage.setItem(PROFILE_KEY(), JSON.stringify({ ...(profile as any), ...next }));
  } catch {}
}

  // ESC to close modal
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && openEpisodeId) {
        e.preventDefault();
        closeEpisode();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [openEpisodeId]);

  // Share helpers
  const shareUrl = (epId: string) => `${location.origin}${location.pathname}#${epId}`;

const tryWebShare = async (title: string, text: string, url: string) => {
  try {
    // @ts-ignore
    if (navigator.share) {
      // @ts-ignore
      await navigator.share({ title, text, url });
      return true;
    }
  } catch (e) {
    // ignore
  }
  return false;
};

// Render local-only profile route for "#u" (overlay handles "#u/...").
if (publicRoute && publicRoute.toLowerCase() === 'u') {
  return (
    <PublicProfileView
      profile={profile}
      episodes={episodes}
      ratings={ratings}
      favs={favs}
      reviews={reviews}
      collections={collections}
      onExit={() => { history.replaceState(null,'',location.pathname); setPublicRoute(null); }}
    />
  );
}

  const epForModal = React.useMemo(() => {
  return openEpisodeId ? (episodes.find(e => e.id === openEpisodeId) ?? null) : null;
}, [openEpisodeId, episodes]);

const publics = React.useMemo(() => epForModal ? getDemoPublicReviews(epForModal.id) : [], [epForModal]);

const avgStars = React.useMemo(() => {
  if (!epForModal) return 0;
  const stars: number[] = [];
  if (typeof ratings?.[epForModal.id] === 'number') stars.push(ratings[epForModal.id]);
  (publics || []).forEach((p: any) => { if (typeof p?.stars === 'number') stars.push(p.stars); });
  return stars.length ? stars.reduce((a, b) => a + b, 0) / stars.length : 0;
}, [epForModal, ratings, publics]);

/* ===================== [CTX-BUILD-START] ===================== */
const ctx = {
  // auth / identity
  user,
  isAdmin,

  // core data
  profile,
  episodes, catalog, ratings, favs, reviews, collections, activity,
  watchedAt, openEpisode,

  // profile counts & subtabs
  followersCount, followingCount, setFollowersCount, setFollowingCount,
  profileTab, setProfileTab,

  // feed view
  reviewView, setReviewView,

  // ui / nav
  tab, setTab, goTab, openHandleProfile, notifCount,

  // public replies local cache
  publicReplies, setPublicReplies, addPublicReply,

  // comments & reactions helpers you already have
  loadComments,
  // (include any other handlers you see used in tab UIs, add here as needed)
    editReview,
  deleteReview,

  // uploads (profile header)
  handleAvatarFileChange, handleCoverFileChange,
  avatarFileRef, coverFileRef, setAvatarCropSrc, setCoverCropSrc,

  // supabase & flags
  supabase, hasSupabaseConfig,

  // reactions
  toggleReviewReaction
};
/* ====================== [CTX-BUILD-END] ====================== */

  return (
    <AppShell user={user} profile={profile}>
  <AppCtx.Provider value={ctx}>
    <ErrorBoundary>
      <a href="#main" className="skip-link">Skip to content</a>
      <div id="main" style={{ padding: 16, background:'#111', color:'#fff', fontFamily:'ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto' }}>
        <GlobalStyles />
{/* TOAST: save confirmation / warnings */}
{saveToast && (
  <div
    role="status"
    aria-live="polite"
    style={{
      position: 'fixed',
      left: '50%',
      bottom: 16,
      transform: 'translateX(-50%)',
      background: '#14132b',
      border: '1px solid var(--line)',
      color: '#fff',
      borderRadius: 12,
      padding: '10px 14px',
      boxShadow: 'var(--shadow)',
      zIndex: 2000
    }}
  >
    {saveToast}
  </div>
)}
        
        {avatarCropSrc && (
  <AvatarCropModal
    src={avatarCropSrc}
    onClose={() => setAvatarCropSrc(null)}
    onSave={(dataUrl) => { setProfile(p => ({ ...p, avatar: dataUrl })); setAvatarCropSrc(null); setTimeout(async () => {
   await saveProfileNow();
   setUnsaved(false);
   setSaveToast('Saved avatar');
   setTimeout(()=>setSaveToast(''), 1500);
 }, 0); 
                         }}
  />
)}
{coverCropSrc && (
  <CoverCropModal
    src={coverCropSrc}
    onClose={() => setCoverCropSrc(null)}
    onSave={(dataUrl) => { setProfile(p => ({ ...p, cover_url: dataUrl })); setCoverCropSrc(null); setTimeout(async () => {
   await saveProfileNow();
   setUnsaved(false);
   setSaveToast('Saved cover');
   setTimeout(()=>setSaveToast(''), 1500);
 }, 0); }}
  />
)}

        {showReset && <ResetPasswordModal onClose={() => setShowReset(false)} />}

{/* Top bar */}
<div
  className="top-bar"
  style={{
    display:'flex',
    gap:12,
    alignItems:'center',
    justifyContent:'space-between',
    padding:'12px 12px',
    border:'1px solid var(--line)',
    borderRadius:'var(--radius-xl)',
    position:'sticky',
    top:8,
    zIndex:100,
    background:'linear-gradient(180deg, rgba(21,20,36,.92), rgba(21,20,36,.72) 55%, rgba(21,20,36,0))',
    backdropFilter:'blur(8px)',
    boxShadow:'var(--shadow)'
  }}
  role="navigation"
  aria-label="Top bar"
>

          {/* Tabs */}
         <div className="tabs" style={{display:'flex',gap:8}}>
  <button type="button" onClick={()=>goTab('browse')} className={tab==='browse'?'active':''} aria-current={tab==='browse'?'page':undefined}>Browse</button>
  {user && (
    <>
      <button type="button" onClick={()=>goTab('diary')} className={tab==='diary'?'active':''} aria-current={tab==='diary'?'page':undefined}>Diary</button>
      <button type="button" onClick={()=>goTab('collections')} className={tab==='collections'?'active':''} aria-current={tab==='collections'?'page':undefined}>Collections</button>
      <button type="button" onClick={()=>goTab('friends')} className={tab==='friends'?'active':''} aria-current={tab==='friends'?'page':undefined}>Friends</button>
      <button type="button" onClick={()=>goTab('notifications')} className={tab==='notifications'?'active':''} aria-label={`Notifications ${notifCount ? `(${notifCount})` : ''}`} title="Notifications">🍸{notifCount ? ` (${notifCount})` : ''}</button>
      <button type="button" onClick={()=>goTab('profile')} className={tab==='profile'?'active':''} aria-current={tab==='profile'?'page':undefined}>Profile</button>
      <button
  type="button"
  onClick={()=>goTab('settings')}
  className="tab-btn"
  aria-current={tab==='settings'?'page':undefined}
>
  Settings
</button>

    </>
  )}
           <TopAuthBar user={user} profile={profile} />

</div>
        
        {/* Content */}
        {!user && tab!=='browse' && (
  <div className="episode-card" style={{marginBottom:12}}>
    <h3 style={{margin:0}}>Please log in</h3>
    <p className="review-meta" style={{marginTop:6}}>Please create an account or log in from the top-right to use this section!</p>
  </div>
)}
</div>       
        <div style={{marginTop:16}}>
                    {tab==='browse' && (
           <BrowseTab
  episodes={episodes}
  finalList={finalList}
  query={query}
  setQuery={setQuery}
  searchIn={searchIn}
  setSearchIn={setSearchIn}
  seasonFilter={seasonFilter}
  setSeasonFilter={setSeasonFilter}
  seasonOptions={seasonOptions}
  minStars={minStars}
  setMinStars={setMinStars}
  onlyFavs={onlyFavs}
  setOnlyFavs={setOnlyFavs}
  onlyRated={onlyRated}
  setOnlyRated={setOnlyRated}
  onlyWatched={onlyWatched}
  setOnlyWatched={setOnlyWatched}
  onlyUnwatched={onlyUnwatched}
  setOnlyUnwatched={setOnlyUnwatched}
  hideWatched={hideWatched}
  setHideWatched={setHideWatched}
  sortBy={sortBy}
  setSortBy={setSortBy}
  funny={funny}
  setFunny={setFunny}
  resetFilters={resetFilters}
  collections={collections}
  collectionFilterId={collectionFilterId}
  setCollectionFilterId={setCollectionFilterId}
  episodeTags={episodeTags}
  ratings={ratings}
  favs={favs}
  watchedAt={watchedAt}
  watchDates={watchDates}
  watchCounts={watchCounts}
  watchDateFilter={watchDateFilter}
  setWatchDateFilter={setWatchDateFilter}
  openEpisode={openEpisode}
  addReview={addReview}
  reviews={reviews}
  commentsByReview={commentsByReview}
  loadComments={loadComments}
  addComment={addComment}
  toggleCommentReaction={toggleCommentReaction}
  toggleReviewReaction={toggleReviewReaction}
/>
          )}

                    {user && tab==='diary' && (
            <DiaryTab
              episodes={episodes}
              ratings={ratings}
              favs={favs}
              watched={watched}
              isInDiary={isInDiary}
              openReviewModal={openReviewModal}
              isEpisodeInAnyCollection={isEpisodeInAnyCollection}
              collections={collections}
              episodeTags={episodeTags}
              setCollectionPickerOpen={setCollectionPickerOpen}
              setCollectionPickerTargetEp={setCollectionPickerTargetEp}
            />
          )}

          {user && tab==='friends' && <FriendsTab />}
          {user && tab==='notifications' && (
  <NotificationsTab
    userId={user?.id ?? null}
    setNotifCount={setNotifCount}
  />
)}

{tab==='collections' && (
            <CollectionsTab
              collections={collections}
              setCollections={setCollections}
              episodes={episodes}
              setTab={setTab}
              setQuery={setQuery}
              setFunny={setFunny}
              setCollectionFilterId={setCollectionFilterId}
              updateCollection={updateCollection}
              addActivity={addActivity}
              episodeTags={episodeTags}
            />
          )}
{/* [TAB-PROFILE-RENDER] */}
          <ProfileTab />
{user && tab==='settings' && (
  <SettingsTab
    goTab={goTab}
    supabase={supabase}
    hasSupabaseConfig={hasSupabaseConfig}
    pushToast={pushToast}
    profile={profile}
    setProfile={setProfile}
    unsaved={unsaved}
    setUnsaved={setUnsaved}
    avatarFileRef={avatarFileRef}
    handleAvatarFileChange={handleAvatarFileChange}
    coverFileRef={coverFileRef}
    handleCoverFileChange={handleCoverFileChange}
    saveProfileNow={saveProfileNow}
    savingProfile={savingProfile}
    setSaveToast={setSaveToast}
  />
)}

{epForModal ? (
  <div
    className="modal-backdrop"
    role="dialog"
    aria-modal="true"
    aria-label={`Episode S${epForModal.season}E${epForModal.episode}`}
  >
    <div className="modal-panel">
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 12,
          flexWrap: 'wrap',
        }}
      >
        <h3 style={{ margin: 0 }}>
          S{epForModal.season}E{epForModal.episode}: {epForModal.title}
        </h3>

        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <RatingInput
            value={ratings[epForModal.id] || 0}
            onChange={(v) => setRating(epForModal.id, v)}
          />
          <HeartButton
            active={!!favs[epForModal.id]}
            onToggle={() => toggleFav(epForModal.id)}
          />
          
<div style={{ display:'inline-flex', gap:8, alignItems:'center' }}>
  <input
    type="date"
    value={watchDateInputs[epForModal.id] ?? todayISO()}
    onChange={e => setWatchDateInputs(m => ({ ...m, [epForModal.id]: e.target.value }))}
  />
  <button
    type="button"
    className="clear-btn"
    onClick={async ()=>{ await logWatch(epForModal.id, watchDateInputs[epForModal.id] ?? todayISO()); }}
  >
    Log watch
  </button>
  <button
    type="button"
    className="clear-btn"
    disabled={!(watchCounts[epForModal.id] > 0)}
    onClick={()=> deleteLatestReview(epForModal.id)}
  >
    Delete review
  </button>
</div>

          <div
            aria-label="Average rating"
            title={`Average: ${avgStars.toFixed(1)}★`}
            style={{ fontSize: 18, display: 'inline-block', minWidth: 120 }}
          >
            {formatStars(Math.round(avgStars * 2) / 2)}
            <span className="review-meta" style={{ marginLeft: 8 }}>
              ({avgStars.toFixed(1)})
            </span>
          </div>

          <button
            type="button"
            className="clear-btn"
            aria-label="Copy episode link"
            onClick={async () => {
              const url = `${location.origin}${location.pathname}#${epForModal.id}`;
              const shared = await (async () => {
                try { /* @ts-ignore */ if (navigator.share) { /* @ts-ignore */ await navigator.share({ title:`S${epForModal.season}E${epForModal.episode}: ${epForModal.title}`, text:'Check this episode', url }); return true; } } catch {}
                return false;
              })();
              if (!shared) {
                const ok = await copyText(url);
                pushToast(ok ? 'Link copied!' : 'Copy failed');
              }
            }}
          >
            Copy link
          </button>

          <button type="button" className="clear-btn" onClick={()=>{
            // closeEpisode() is your helper
            closeEpisode();
          }} aria-label="Close episode">
            Close
          </button>
        </div>
      </div>

      <p style={{ marginTop: 6, opacity: 0.9 }}>{epForModal.description}</p>

      {/* Review filter switch */}
      <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
        <button
          type="button"
          className="clear-btn"
          onClick={() => setReviewView('all')}
          aria-pressed={reviewView === 'all'}
        >
          All
        </button>
        <button
          type="button"
          className="clear-btn"
          onClick={() => setReviewView('mine')}
          aria-pressed={reviewView === 'mine'}
        >
          Mine
        </button>
        <button
          type="button"
          className="clear-btn"
          onClick={() => setReviewView('public')}
          aria-pressed={reviewView === 'public'}
        >
          Public
        </button>
      </div>

      {/* Your own reviews for this episode */}
      <EpisodeReviews
  ep={epForModal}
  epId={epForModal.id}
  reviews={reviews[epForModal.id] || []}
  onEdit={editReview}
  onDelete={deleteReview}
  onAdd={addReview}
  episodeStars={ratings[epForModal.id] || 0}
  episodeHearted={!!favs[epForModal.id]}
  commentsByReview={commentsByReview}
  loadComments={loadComments}
  addComment={addComment}
  toggleCommentReaction={toggleCommentReaction}
  toggleReviewReaction={toggleReviewReaction}

/>
     
      {/* Public reviews (demo) + replies */}
{reviewView !== 'mine' && (
  <div className="episode-card" style={{ marginTop: 12 }}>
    <h4 style={{ margin: 0 }}>Public reviews (demo)</h4>
    {publics.length === 0 ? (
      <p style={{ color: '#bbb', marginTop: 8 }}>No public reviews yet.</p>
    ) : (
      <ul className="review-list" style={{ marginTop: 10 }}>
        {publics.map((p: any) => {
          const replies = publicReplies[p.id] || [];
          return (
            <li
              key={p.id}
              style={{
                border: '1px solid #333',
                borderRadius: 10,
                padding: 10,
                background: '#0f0f0f',
              }}
            >
              {/* Public review header with (optional) avatar/name/handle */}
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ width:28, height:28, borderRadius:'50%', overflow:'hidden', border:'1px solid #333', background:'#222', display:'grid', placeItems:'center' }}>
                  {p.avatar
                    ? <img src={p.avatar} alt="" width={28} height={28} style={{objectFit:'cover',width:'100%',height:'100%'}}/>
                    : <span style={{ fontSize:12, color:'#aaa' }}>👤</span>}
                </div>
                <div style={{ fontSize:13 }}>
                  <strong>{p.author || 'User'}</strong>
                  {p.handle ? <span style={{ opacity:.7 }}> · {p.handle}</span> : null}
                </div>
                <div className="review-meta" style={{ marginLeft:'auto' }}>
                  {new Date(p.ts).toLocaleString()}
                </div>
              </div>

              <div style={{ whiteSpace: 'pre-wrap', marginTop: 6 }}>{p.text}</div>

              {/* Replies (list) */}
              {replies.length > 0 && (
                <ul style={{ listStyle:'none', padding:0, margin:'10px 0 0', display:'grid', gap:8 }}>
                  {replies.map(r => (
                    <li key={r.id} style={{ border:'1px solid #333', borderRadius:10, padding:10, background:'#101010' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                        <div style={{ width:24, height:24, borderRadius:'50%', overflow:'hidden', border:'1px solid #333', background:'#222', display:'grid', placeItems:'center' }}>
                          {r.authorAvatar
                            ? <img src={r.authorAvatar} alt="" width={24} height={24} style={{objectFit:'cover',width:'100%',height:'100%'}}/>
                            : <span style={{ fontSize:11, color:'#aaa' }}>👤</span>}
                        </div>
                        <div style={{ fontSize:12 }}>
                          <strong>{r.authorName || 'You'}</strong>
                          {r.authorHandle ? <span style={{ opacity:.7 }}> · {r.authorHandle}</span> : null}
                        </div>
                        <div className="review-meta" style={{ marginLeft:'auto' }}>
                          {new Date(r.ts).toLocaleString()}
                        </div>
                      </div>
                      <div style={{ whiteSpace:'pre-wrap', marginTop:6 }}>{r.text}</div>
                    </li>
                  ))}
                </ul>
              )}

              {/* Reply box */}
              <div style={{ display:'flex', gap:6, alignItems:'flex-start', marginTop:10 }}>
                <textarea
                  className="input"
                  rows={2}
                  placeholder="Write a reply…"
                  style={{ flex:1, minHeight:56 }}
                  id={`reply-${p.id}`}
                />
                <button
                  type="button"
                  className="clear-btn"
                  onClick={()=>{
                    const el = document.getElementById(`reply-${p.id}`) as HTMLTextAreaElement | null;
                    const t = el?.value || '';
                    if (!t.trim()) return;
                    addPublicReply(p.id, t);
                    if (el) el.value = '';
                  }}
                >
                  Reply
                </button>
              </div>
            </li>
          );
        })}
      </ul>
    )}
  </div>
)}
    </div>
  </div>
) : null}
        </div>
      </div>
    </ErrorBoundary>
    </AppCtx.Provider>
      <ToastHost />
</AppShell>
  );
}